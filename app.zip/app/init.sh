#!/usr/bin/env bash

declare -A MODULES

MODULES=(
    ["git@git.axelor.com:aop/addons/axelor-public/axelor-utils.git"]="main"
    ["git@git.axelor.com:aop/addons/axelor-public/axelor-message.git"]="main"
    ["git@git.axelor.com:aop/addons/axelor-public/axelor-studio.git"]="main"
    ["git@git.axelor.com:aop/addons/axelor-private/axelor-studio-pro.git"]="main"
    ["git@git.axelor.com:aop/addons/axelor-private/axelor-analytics.git"]="main"
)

GREEN="\033[0;32m"
CYAN="\033[0;36m"
NOCOLOR="\033[0m"

function print_step() {
    echo -e "${GREEN}$1${NOCOLOR}"
}

function print_sub_step() {
    echo -e "${CYAN}  * $1${NOCOLOR}"
}

function extract_git_repo_name() {
    echo "$1" | sed -E 's/.*\/(.*)\.git/\1/'
}

print_step "Creating an AOP Addons demo application..."

git clean -fdx >/dev/null 2>&1
for MODULE in "${!MODULES[@]}"; do
    print_sub_step "Removing $(extract_git_repo_name $MODULE)..."
    rm -rf "open-platform-demo/modules/$(extract_git_repo_name $MODULE)"
done

cd open-platform-demo/modules
for MODULE in "${!MODULES[@]}"; do
    print_sub_step "Cloning $(extract_git_repo_name $MODULE)..."
    git clone $MODULE -b ${MODULES[$MODULE]} >/dev/null 2>&1
done
cd - >/dev/null 2>&1

print_sub_step "Building the application..."
cd open-platform-demo
./gradlew clean assemble -Dinclude.react
cd - >/dev/null 2>&1