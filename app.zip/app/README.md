# Create AOP Addons App

## Usage

```bash
git clone git@git.axelor.com:aop/addons/axelor-test/create-aop-addons-app.git && cd create-aop-addons-app && ./init.sh
```
